import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class AccountNumber {
    private int accountNumber; 
    Users user = new Users();
    private int balance = 500;

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    boolean isAccountNumberExist(int accountNumber) {
        if (user.checkFile(accountNumber)) {
            return true;
        } else {
            return false;
        }
    }

} 

class Users {
    final static String USER__DATA = "allUserAccountNumber.txt";
    final static String USER__DIR = "users/";

    public String getUSER__DATA() {
        return USER__DATA;
    }

    void newUser(AccountNumber ac) {

        try {
            FileWriter writer = new FileWriter(USER__DATA, true);
            int accountNumber = ac.getAccountNumber();
            writer.write(Integer.toString(accountNumber) + "\n");

            writer.close();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    } 
    
    public static void deleteUser(AccountNumber ac) {
        try {
            File originalFile = new File(USER__DATA);
            File tempFile = new File("temp_user_data.txt");

            BufferedReader reader = new BufferedReader(new FileReader(originalFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String acToBeDeleted = Integer.toString(ac.getAccountNumber());
            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                if (currentLine.contains(acToBeDeleted)) continue;
                writer.write(currentLine + System.lineSeparator());
            }

            writer.close();
            reader.close();

            if (!originalFile.delete()) {
                System.out.println("Could not delete original user data file.");
                return;
            }

            if (!tempFile.renameTo(originalFile)) {
                System.out.println("Could not rename temporary user data file.");
            }

            File userFile = new File(USER__DIR + ac.getAccountNumber() + ".txt");
            if (userFile.exists()) {
                if (!userFile.delete()) {
                    System.out.println("Could not delete user file.");
                }
            } else {
                System.out.println("User file does not exist.");
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static boolean checkFile(int accountNumberToCheck) {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER__DATA))) {
            String line;
            while ((line = reader.readLine()) != null) {

                int accountNumber = Integer.parseInt(line.trim());
                if (accountNumber == accountNumberToCheck) {
                    return true; 
                }
            }
        } catch (IOException | NumberFormatException ex) {
            System.err.println("Error reading the file: " + ex.getMessage());
            ex.printStackTrace();
        }
        return false; 
    }
}

class FileManipulation {
    static Users user = new Users();

    public static void getFileContents(String fileName) {
        String directory = "users"; 
        Path filePath = Paths.get(directory, fileName); 

        if (!Files.exists(filePath)) {
            System.out.println("File not found: " + filePath);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath.toFile()))) {
            String line;
            StringBuilder contentBuilder = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line).append("\n");
            }
            String fileContents = contentBuilder.toString();
            System.out.println("File contents:");
            System.out.println(fileContents);
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void createNewFile(AccountNumber ac, int PIN) {
        String fileName = "users/" + ac.getAccountNumber() + ".txt"; 

        try {
            FileWriter writer = new FileWriter(fileName, true);
            writer.write(Integer.toString(PIN) + "\n");
            writer.close();
        } catch (IOException ex) {
            System.out.println("Error creating file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void creditAmount(AccountNumber ac, int PIN, int amount) {
        int storedPin = readPinFromFile(ac);
        
        if (PIN == storedPin) {
            System.out.println("PIN verified.");
            
            LocalDateTime transactionTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedTransactionTime = transactionTime.format(formatter);

            try {
                String fileName = "users/" + ac.getAccountNumber() + ".txt"; 
                FileWriter writer = new FileWriter(fileName, true);

                int balance = getLastBalance(ac, fileName);
                balance += amount;
                writer.write(formattedTransactionTime + " = " + amount + " is credited\n");
                writer.write(formattedTransactionTime + " Total balance is: " + balance + "\n\n");

                writer.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else {
            System.out.println("Incorrect PIN. Unable to credit amount.");
        }
    }

    public static int readPinFromFile(AccountNumber ac) {
        String fileName = "users/" + ac.getAccountNumber() + ".txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            return Integer.parseInt(reader.readLine());
        } catch (IOException | NumberFormatException ex) {
            System.out.println("Error reading PIN from file: " + ex.getMessage());
            return -1; 
        }
    }

    public static void debitAmount(AccountNumber ac, int PIN, int amount) {
        int storedPin = readPinFromFile(ac);
        
        if (PIN == storedPin) {
            System.out.println("PIN verified.");
            
            LocalDateTime transactionTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formattedTransactionTime = transactionTime.format(formatter);

            try {
                String fileName = "users/" + ac.getAccountNumber() + ".txt"; 
                FileWriter writer = new FileWriter(fileName, true);

                int balance = getLastBalance(ac, fileName);
                if (balance >= amount) {
                    balance -= amount;
                    writer.write(formattedTransactionTime + " = " + amount + " is debited\n");
                    writer.write(formattedTransactionTime + " Total balance is: " + balance + "\n\n");
                } else {
                    System.out.println("Insufficient balance. Unable to debit amount.");
                }

                writer.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else {
            System.out.println("Incorrect PIN. Unable to debit amount.");
        }
    }

    public static int getLastBalance(AccountNumber ac, String fileName) {
        int lastBalance = 0;
        String line;
        fileName = "users/" + ac.getAccountNumber() + ".txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line = reader.readLine()) != null) {
                if (line.contains("Total balance is:")) {
                    String[] parts = line.split(": ");
                    lastBalance = Integer.parseInt(parts[1].trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lastBalance;
    }

    public static void transferingAmount(AccountNumber sender, int senderPIN, int receiver, int amount) {
        if (!authenticateUser(sender, senderPIN)) {
            System.out.println("Sender authentication failed. Transfer aborted.");
            return;
        }

        if (!deductAmount(sender, senderPIN, amount)) {
            System.out.println("Insufficient funds in sender's account. Transfer aborted.");
            return;
        }

        if (!depositAmount(receiver, amount)) {
            System.out.println("Error transferring amount to recipient. Transfer aborted.");
            return;
        }

        updateTransactionRecords(sender, receiver, amount);
        
        System.out.println("Transfer successful.");
    }

    private static boolean authenticateUser(AccountNumber ac, int PIN) {
            if(!user.checkFile(ac.getAccountNumber())) {
                return false;
            }
        return true; 
    }

    private static boolean deductAmount(AccountNumber ac, int PIN, int amount) {
        debitAmount(ac, PIN, amount);
        return true; 
    }

    private static boolean depositAmount(int recipientAc, int amount) {
        LocalDateTime transactionTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTransactionTime = transactionTime.format(formatter);

        try {
            String fileName = "users/" + recipientAc + ".txt"; 
            FileWriter writer = new FileWriter(fileName, true);
            
            int lastBalance = 0;
            String line;
            fileName = "users/" + recipientAc + ".txt";
            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                while ((line = reader.readLine()) != null) {
                    if (line.contains("Total balance is:")) {
                        String[] parts = line.split(": ");
                        lastBalance = Integer.parseInt(parts[1].trim());
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            lastBalance += amount;
            writer.write(formattedTransactionTime + " = " + amount + " is credited\n");
            writer.write(formattedTransactionTime + " Total balance is: " + lastBalance + "\n\n");

            writer.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return true; 
    }

    private static void updateTransactionRecords(AccountNumber sender, int receiver, int amount) {
        // System.out.println("inside function");
        LocalDateTime transactionTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTransactionTime = transactionTime.format(formatter);
        
        try {
            // System.out.println("inside try");
            String fileName = "TransferingFundsRecords.txt";
            FileWriter writer = new FileWriter(fileName, true);
            
            writer.write(formattedTransactionTime + " Sender Account Number: " + sender.getAccountNumber() + "\n");
            writer.write(formattedTransactionTime + " Receiver Account Number: " + receiver + "\n");
            writer.write(formattedTransactionTime + " Transfered Amount: " + amount + "\n\n");
            
            // System.out.println("before close");
            writer.close();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}

public class Process {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AccountNumber ac = new AccountNumber();
        Users user = new Users();
        FileManipulation dataManipulation = new FileManipulation();
        
        System.out.println("Enter Account Number");
        int accountNumber = sc.nextInt();

        if (ac.isAccountNumberExist(accountNumber)) {
            System.out.println("Set 6 digit PIN");
            int PIN = sc.nextInt();
            ac.setAccountNumber(accountNumber);
            int storedPin = dataManipulation.readPinFromFile(ac);

            if (PIN != storedPin) {
                System.out.println("PIN IS INVALID. COLLECT YOUR CARD FROM THE CARD-TRAY!!");   
                System.exit(0);
            }   
        } else {
            System.out.println("Welcome Your account is created");

            ac.setAccountNumber(accountNumber);
            user.newUser(ac);
            
            System.out.println("Set 6 digit PIN");
            int PIN = sc.nextInt();
            dataManipulation.createNewFile(ac, PIN);

        }

        int choice;
        do {
            System.out.println("\n1.Credit Amount");
            System.out.println("2.Debit Amount");
            System.out.println("3.show Tansactions");
            System.out.println("4.Exit");
            System.out.println("5.View Balance");
            System.out.println("6.Delete Account");
            System.out.println("7.Transfer Funds");

            System.out.println("\nEnter choice: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1: 
                    System.out.println("Enter PIN: ");
                    int PIN = sc.nextInt();

                    System.out.println("Enter amount: ");
                    int amount = sc.nextInt();

                    dataManipulation.creditAmount(ac, PIN, amount); 
                    break;

                case 2:
                    System.out.println("Enter PIN: ");
                    PIN = sc.nextInt();

                    System.out.println("Enter amount: ");
                    amount = sc.nextInt();

                    dataManipulation.debitAmount(ac, PIN, amount);  
                    break;

                case 3: 
                    String file_name = Integer.toString(ac.getAccountNumber()) + ".txt";
                    dataManipulation.getFileContents(file_name);
                  break;
                case 4: System.exit(0); break;
                
                case 5: 
                    file_name = Integer.toString(ac.getAccountNumber()) + ".txt";
                    System.out.println("Your Balane is: " + dataManipulation.getLastBalance(ac, file_name));
                    
                    break;
                case 6: 
                    file_name = Integer.toString(ac.getAccountNumber()) + ".txt";
                    System.out.println("ARE YOU SURE TO DELETE YOUR ACCOUNT? THEN TYPE yes");
                    sc.next();
                    String confirm = sc.nextLine();
                    confirm = confirm.toLowerCase();

                    if (confirm == "yes") {
                        user.deleteUser(ac);
                        System.out.println("YOUR ACCOUNT HAS BEEN DELETED");
                    }
                    break;
                
                case 7: 
                    System.out.println("Enter Account Number of Reciver: ");
                    int reciverAc = sc.nextInt();

                    System.out.println("Enter PIN: ");
                    PIN = sc.nextInt();

                    System.out.println("Enter amount: ");
                    amount = sc.nextInt();

                    dataManipulation.transferingAmount(ac, PIN, reciverAc, amount);
                    
                
                break;

                default: System.out.println("INVALID CHOICE!!"); break;
            }
        } while (choice != 4);

        sc.close();
    }
}