import os
import os.path
import pickle
import base64
import json
import nltk
import string
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

ps = PorterStemmer()

# ! it is used to connect with gmail and credential validation
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

# TODO: Function to authenticate and create Gmail API service

def authenticate_gmail():
    creds = None
    # ! Pickle file is used to authenticate user for the first then and life span is 1 hour
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # ! it will prompt user to sign in window
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('gmail', 'v1', credentials=creds)
    return service

def transform_text(text):
    text = text.lower()
    text = nltk.word_tokenize(text)
    y = [i for i in text if i.isalnum()]
    text = y[:]
    y.clear()

    for i in text:
        if i not in stopwords.words('english') and i not in string.punctuation:
            y.append(i)

    text = y[:]
    y.clear()

    for i in text:
        y.append(ps.stem(i))

    return " ".join(y)

def get_emails(service, model, tfidf):
    max_results = int(input("How many recent emails do you want to check for spam? "))
    
    emails_checked = 0
    next_page_token = None

    while emails_checked < max_results:
        # ! Fetch emails 
        results = service.users().messages().list(userId='me', maxResults=100, pageToken=next_page_token).execute()
        messages = results.get('messages', [])
        
        if not messages:
            print('No more emails found.')
            break
        
        for message in messages:
            if emails_checked >= max_results:
                break 

            msg = service.users().messages().get(userId='me', id=message['id']).execute()
            payload = msg['payload']
            headers = payload.get("headers")
            
            subject = None
            for header in headers:
                if header['name'] == 'Subject':
                    subject = header['value']
                    break

            body = ""
            if 'data' in payload['body']:
                body = base64.urlsafe_b64decode(payload['body']['data']).decode('ut f-8')
            else:
                # ! If the email body is not in 'data' it will check for 'parts'
                parts = payload.get('parts', [])
                if parts:
                    for part in parts:
                        if part['mimeType'] == 'text/plain':
                            body = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                            break
            
            transformed_sms = transform_text(body)

            # ! Convert transformed text to TF-IDF vector
            vector_input = tfidf.transform([transformed_sms])

            result = model.predict(vector_input)[0]
            
            print(f"Subject: {subject}")
            print(f"Spam: {'Yes' if result == 1 else 'No'}\n")
            
            emails_checked += 1  
        
        next_page_token = results.get('nextPageToken')  
        if not next_page_token:
            break 

def main():
    service = authenticate_gmail()
    
    model = pickle.load(open('model.pkl', 'rb'))
    tfidf = pickle.load(open('vectorizer.pkl', 'rb'))

    get_emails(service, model, tfidf)

if __name__ == '__main__':
    main()