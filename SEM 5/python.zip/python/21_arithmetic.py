import Asetters as a

a, b = a.setters()

print(f"A: {a}, b: {b}")