def setters():
    x = int(input("Enter: "))
    y = int(input("Enter: "))
    
    return x, y
